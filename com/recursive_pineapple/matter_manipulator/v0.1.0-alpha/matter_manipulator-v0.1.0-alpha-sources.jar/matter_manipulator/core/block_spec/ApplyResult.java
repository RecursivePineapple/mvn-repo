package matter_manipulator.core.block_spec;

import java.util.Set;

public enum ApplyResult {
    DidNothing,
    /// The block/tile was invalid for the given operation, and nothing was done.
    NotApplicable,
    /// Did an action that could be performed by a wrench (rotated, etc). Will show wrench particles.
    Wrenched,
    /// Did a generic action (will play an enderman portal sound).
    DidSomething,
    /// The operation was valid, but failed for some reason (insufficient resources, illegal block location, etc).
    Retry,
    /// An unrecoverable error occured and the block is in an undefined state. No further operations will be performed.
    Error,
    ;

    public static boolean hasFailure(Set<ApplyResult> result) {
        return result.contains(Retry) || result.contains(Error);
    }
}
