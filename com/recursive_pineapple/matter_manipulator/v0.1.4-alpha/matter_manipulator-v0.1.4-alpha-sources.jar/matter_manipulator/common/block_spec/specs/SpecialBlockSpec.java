package matter_manipulator.common.block_spec.specs;

import java.util.EnumSet;
import java.util.concurrent.ThreadLocalRandom;

import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemBlockSpecial;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;

import org.apache.commons.lang3.mutable.MutableObject;

import lombok.EqualsAndHashCode;
import matter_manipulator.common.block_spec.AbstractBlockSpec;
import matter_manipulator.common.block_spec.adapters.SpecialBlockSpecAdapter;
import matter_manipulator.common.interop.MMRegistriesInternal;
import matter_manipulator.common.utils.math.Transform;
import matter_manipulator.core.block_spec.ApplyResult;
import matter_manipulator.core.block_spec.BlockSpec;
import matter_manipulator.core.block_spec.BlockSpecLoader;
import matter_manipulator.core.resources.item.ItemStackWrapper;

/// A [BlockSpec] that places a block, along with some interop state. The block must be backed 1:1 by a standard
/// [ItemBlock].
@EqualsAndHashCode(callSuper = false)
public class SpecialBlockSpec extends AbstractBlockSpec {

    public IBlockState state;

    @EqualsAndHashCode.Exclude
    private boolean hasResource = false;
    @EqualsAndHashCode.Exclude
    private ItemStackWrapper resource;

    public SpecialBlockSpec(IBlockState state) {
        this.state = state;
    }

    @Override
    public BlockSpecLoader getLoader() {
        return SpecialBlockSpecAdapter.INSTANCE;
    }

    @Override
    public IBlockState getBlockState() {
        return state;
    }

    @Override
    public boolean isValid() {
        return state.getBlock().getItemDropped(state, ThreadLocalRandom.current(), 0) instanceof ItemBlockSpecial;
    }

    @Override
    public ItemStackWrapper getResource() {
        if (hasResource) return resource;

        hasResource = true;
        resource = new ItemStackWrapper(new ItemStack(
            state.getBlock().getItemDropped(state, ThreadLocalRandom.current(), 0),
            1,
            state.getBlock().damageDropped(state)));;

        modifyResource(resource);

        return resource;
    }

    @SuppressWarnings("unchecked")
    @Override
    public void transform(Transform transform) {
        super.transform(transform);

        for (IProperty<?> prop : state.getPropertyKeys()) {
            if (prop.getName().equals("facing") && prop.getValueClass() == EnumFacing.class) {
                EnumFacing facing = state.getValue((IProperty<EnumFacing>) prop);

                transform.apply(facing);

                state = state.withProperty((IProperty<EnumFacing>) prop, facing);
            }
        }
    }

    @Override
    public SpecialBlockSpec clone() {
        return (SpecialBlockSpec) super.clone();
    }

    @Override
    protected void resetResource() {
        this.hasResource = false;
        this.resource = null;
    }

    @Override
    public BlockSpec sanitized() {
        ItemStackWrapper stack = getResource();

        if (!(stack.getItem() instanceof ItemBlock itemBlock)) return clone();

        int meta = itemBlock.getMetadata(stack.toStackFast(stack.getAmountInt()).getMetadata());

        //noinspection deprecation
        IBlockState base = this.state.getBlock().getStateFromMeta(meta);

        MutableObject<IBlockState> state = new MutableObject<>(base);

        MMRegistriesInternal.transformBlock(state, getBlockState(), EnumSet.noneOf(ApplyResult.class));

        SpecialBlockSpec copy = this.clone();

        copy.state = state.getValue();

        return copy;
    }
}
